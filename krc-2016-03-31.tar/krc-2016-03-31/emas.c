// EMAS emulation stubs

// ON EMAS PROMPTS REMAIN IN EFFECT UNTIL CANCELLED
char *emas_PROMPT = "";

// The extra character gobbled up at the end of a call to READN()
int  TERMINATOR;

